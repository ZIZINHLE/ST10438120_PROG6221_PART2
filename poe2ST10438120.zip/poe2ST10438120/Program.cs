﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.IO;

namespace CybersecurityAwarenessBot
{
    class Program
    {
        static string userName = "";
        static string userInterest = "";
        static List<string> phishingTips = new List<string>
        {
            "Be cautious of emails asking for personal information.",
            "Avoid clicking suspicious links—even if they look familiar.",
            "Check the sender’s email address carefully.",
            "Look for grammar mistakes in suspicious messages.",
            "Hover over links to preview the URL before clicking."
        };

        static Dictionary<string, string> keywordTips = new Dictionary<string, string>
        {
            { "password", "Make sure to use strong, unique passwords for each account. Avoid using personal details." },
            { "scam", "Never share personal info with unknown sources or click on sketchy links." },
            { "privacy", "Review privacy settings on social platforms and limit shared personal info." }
        };

        static Dictionary<string, string> sentimentResponses = new Dictionary<string, string>
        {
            { "worried", "It's okay to feel worried. You're learning and taking steps to protect yourself." },
            { "curious", "Curiosity is the first step toward awareness—ask me anything!" },
            { "frustrated", "I understand. Cybersecurity can be tricky at first. I'm here to help!" }
        };

        static void Main(string[] args)
        {
            PlayVoiceGreeting();
            DisplayAsciiArt();
            userName = GetUserName();

            SimulateTyping($"\n🔐 {userName}, you can ask me anything about staying safe online. Here are some suggestions:\n", 40);
            DisplaySuggestedQuestions();

            while (true)
            {
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.Write("\n💬 What would you like to know? (type 'exit' to quit): ");
                string userInput = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(userInput))
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("⚠️ Please enter something.");
                    continue;
                }

                if (userInput.ToLower().Contains("exit"))
                {
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.WriteLine($"\n👋 Goodbye {userName}, and remember—stay safe online!");
                    break;
                }

                // Save interest if mentioned
                if (userInput.ToLower().Contains("interested in"))
                {
                    var words = userInput.ToLower().Split(' ');
                    int index = Array.IndexOf(words, "in");
                    if (index >= 0 && index < words.Length - 1)
                    {
                        userInterest = words[index + 1];
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        SimulateTyping($"Awesome! I'll remember that you're interested in {userInterest}. 🧠", 40);
                        continue;
                    }
                }

                SimulateTyping(GetBotResponse(userInput), 40);
                Console.ResetColor();
            }
        }

        static void PlayVoiceGreeting()
        {
            try
            {
                string audioPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "VoiceGreeting.wav");

                if (File.Exists(audioPath))
                {
                    SoundPlayer player = new SoundPlayer(audioPath);
                    player.PlaySync();
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("[Audio file not found: VoiceGreeting.wav]");
                    Console.ResetColor();
                }
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"[Error playing audio: {ex.Message}]");
                Console.ResetColor();
            }
        }

        static void DisplayAsciiArt()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(@"
   ____ _           _   _           _   
  / ___| |__   __ _| |_| |__   ___ | |_ 
 | |   | '_ \ / _` | __| '_ \ / _ \| __|
 | |___| | | | (_| | |_| | | | (_) | |_ 
  \____|_| |_|\__,_|\__|_| |_|\___/ \__| 
                                     
       Welcome to the Cybersecurity Awareness Bot!
");
            Console.ResetColor();
        }

        static string GetUserName()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("\n👤 What's your name? ");
            string name = Console.ReadLine();

            while (string.IsNullOrWhiteSpace(name))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("⚠️ Name can't be blank. Please enter your name: ");
                name = Console.ReadLine();
            }

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"\n🌟 Hello, {name}! Let's boost your cyber-smarts.\n");
            Console.ResetColor();
            return name;
        }

        static string GetBotResponse(string input)
        {
            input = input.ToLower();

            // Check for sentiment
            foreach (var sentiment in sentimentResponses)
            {
                if (input.Contains(sentiment.Key))
                    return sentiment.Value;
            }

            // Keyword tips
            foreach (var keyword in keywordTips)
            {
                if (input.Contains(keyword.Key))
                    return keyword.Value;
            }

            // Random phishing tip
            if (input.Contains("phishing"))
            {
                Random rnd = new Random();
                return phishingTips[rnd.Next(phishingTips.Count)];
            }

            // Follow-up with user's interest
            if (!string.IsNullOrEmpty(userInterest) && input.Contains("more"))
            {
                return $"As someone interested in {userInterest}, be sure to explore your account settings and enable extra security features.";
            }

            // Fun response
            if (input.Contains("who created you"))
                return $"I was created by Zizinhle as a cybersecurity project, {userName}. 😄";

            // Unknown input
            return $"I'm not sure I understand, {userName}. Could you try rephrasing?";
        }

        static void DisplaySuggestedQuestions()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(@"
Here are some suggested questions you can ask me:
- What makes a strong password?
- How can I tell if an email is a scam?
- What's the difference between HTTP and HTTPS?
- How do I secure my phone?
- What is malware?
- What is two-factor authentication?
- I'm interested in privacy.
- Give me a phishing tip.
- I'm feeling frustrated.

Feel free to ask anything about online safety!
");
            Console.ResetColor();
        }

        static void SimulateTyping(string text, int delay = 30)
        {
            foreach (char c in text)
            {
                Console.Write(c);
                Thread.Sleep(delay);
            }
            Console.WriteLine();
        }
    }
}
